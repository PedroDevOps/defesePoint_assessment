const AWS = require('aws-sdk');
const Sharp = require('sharp');

const s3 = new AWS.S3();

exports.handler = async (event) => {
  const { imageKey } = JSON.parse(event.body);

  const bucket = process.env.BUCKET;

  try {
    const image = await s3.getObject({ Bucket: bucket, Key: imageKey }).promise();

    const resizedImage = await Sharp(image.Body)
      .resize(100, 100) // Change the size as needed
      .toBuffer();

    await s3.putObject({
      Bucket: bucket,
      Key: `resized-${imageKey}`,
      Body: resizedImage,
      ContentType: 'image/jpeg'
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Image resized successfully' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error resizing image', error }),
    };
  }
};
